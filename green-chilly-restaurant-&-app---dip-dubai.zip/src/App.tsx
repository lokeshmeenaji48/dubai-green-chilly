import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { TablesideSection } from './components/TablesideSection';
import { ReservationSection } from './components/ReservationSection';
import { LocationSection } from './components/LocationSection';
import { Footer } from './components/Footer';
import { TablesideCartDrawer } from './components/TablesideCartDrawer';
import { KitchenTicketModal } from './components/KitchenTicketModal';
import { CartItem, TablesideOrder } from './types';
import { AVAILABLE_TABLES } from './data/restaurantData';
import { Check } from 'lucide-react';

export default function App() {
  const [selectedTable, setSelectedTable] = useState<string>(AVAILABLE_TABLES[0].id);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeKitchenOrder, setActiveKitchenOrder] = useState<TablesideOrder | null>(null);
  const [isKitchenModalOpen, setIsKitchenModalOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('tableside');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const cartCount = cartItems.reduce((acc, curr) => acc + curr.quantity, 0);
  const currentTableObj = AVAILABLE_TABLES.find((t) => t.id === selectedTable) || AVAILABLE_TABLES[0];

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  const handleAddToCart = (newItem: CartItem) => {
    setCartItems((prev) => {
      const existingIndex = prev.findIndex((item) => item.id === newItem.id);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += newItem.quantity;
        return updated;
      } else {
        return [...prev, newItem];
      }
    });
    showToast(`Added ${newItem.quantity}x ${newItem.menuItem.name} to ${currentTableObj.label}`);
  };

  const handleUpdateQuantity = (cartItemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveItem(cartItemId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) => (item.id === cartItemId ? { ...item, quantity: newQuantity } : item))
    );
  };

  const handleRemoveItem = (cartItemId: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== cartItemId));
  };

  const handleFireOrderToKitchen = (order: TablesideOrder) => {
    setActiveKitchenOrder(order);
    setCartItems([]);
    setIsCartOpen(false);
    setIsKitchenModalOpen(true);
    showToast(`Order sent to kitchen for ${order.tableNumber}! Ticket #${order.id}`);
  };

  const handleRequestService = (serviceDescription: string) => {
    showToast(`Service Request Sent: ${serviceDescription}`);
  };

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const el = document.getElementById(sectionId);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-stone-900 text-stone-100 flex flex-col font-sans">
      
      {/* Top Header */}
      <Header
        cartCount={cartCount}
        onOpenCart={() => setIsCartOpen(true)}
        activeSection={activeSection}
        onNavigate={handleNavigate}
        selectedTable={selectedTable}
        onSelectTable={setSelectedTable}
      />

      {/* Main Content: Tableside Ordering, Table Booking & Location */}
      <main className="flex-1">
        <Hero
          onGoToTableside={() => handleNavigate('tableside')}
          onGoToBooking={() => handleNavigate('booking')}
          selectedTableLabel={currentTableObj.label}
        />

        {/* 1. ORDER ON TABLESIDE */}
        <TablesideSection
          selectedTable={selectedTable}
          onSelectTable={setSelectedTable}
          onAddToCart={handleAddToCart}
          onRequestService={handleRequestService}
        />

        {/* 2. TABLE BOOKING */}
        <ReservationSection />

        {/* 3. LOCATION & HOURS */}
        <LocationSection />
      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* Tableside Order / KOT Cart Drawer */}
      <TablesideCartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        selectedTable={selectedTable}
        onSelectTable={setSelectedTable}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onFireOrderToKitchen={handleFireOrderToKitchen}
      />

      {/* Live Kitchen Order Ticket (KOT) Tracker Modal */}
      {isKitchenModalOpen && (
        <KitchenTicketModal
          order={activeKitchenOrder}
          onClose={() => setIsKitchenModalOpen(false)}
          onRequestBill={(tableNum) => handleRequestService(`Bill requested for ${tableNum}`)}
          onCallWaiter={(tableNum) => handleRequestService(`Waiter called to ${tableNum}`)}
        />
      )}

      {/* Floating Service & Order Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-stone-900/95 border border-emerald-500/80 text-white text-xs sm:text-sm font-semibold px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 backdrop-blur-md animate-fade-in">
          <span className="w-5 h-5 rounded-full bg-emerald-600 flex items-center justify-center text-white shrink-0">
            <Check className="w-3 h-3" />
          </span>
          <span>{toastMessage}</span>
        </div>
      )}

    </div>
  );
}
